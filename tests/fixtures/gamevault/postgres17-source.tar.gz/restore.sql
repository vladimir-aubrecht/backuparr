--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE source;
--
-- Name: source; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE source WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE source OWNER TO postgres;

\unrestrict (null)
\connect source
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: gamevault_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gamevault_user (
    id integer NOT NULL,
    username text,
    api_key text,
    password text
);


ALTER TABLE public.gamevault_user OWNER TO postgres;

--
-- Name: gamevault_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gamevault_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gamevault_user_id_seq OWNER TO postgres;

--
-- Name: gamevault_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gamevault_user_id_seq OWNED BY public.gamevault_user.id;


--
-- Name: progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.progress (
    id integer NOT NULL,
    state text,
    minutes_played integer,
    last_played timestamp with time zone
);


ALTER TABLE public.progress OWNER TO postgres;

--
-- Name: progress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.progress_id_seq OWNER TO postgres;

--
-- Name: progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.progress_id_seq OWNED BY public.progress.id;


--
-- Name: strange table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."strange table" (
    "odd column" text,
    "binary" bytea,
    nullable text
);


ALTER TABLE public."strange table" OWNER TO postgres;

--
-- Name: gamevault_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gamevault_user ALTER COLUMN id SET DEFAULT nextval('public.gamevault_user_id_seq'::regclass);


--
-- Name: progress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.progress ALTER COLUMN id SET DEFAULT nextval('public.progress_id_seq'::regclass);


--
-- Data for Name: gamevault_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gamevault_user (id, username, api_key, password) FROM stdin;
\.
COPY public.gamevault_user (id, username, api_key, password) FROM '$$PATH$$/3469.dat';

--
-- Data for Name: progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.progress (id, state, minutes_played, last_played) FROM stdin;
\.
COPY public.progress (id, state, minutes_played, last_played) FROM '$$PATH$$/3471.dat';

--
-- Data for Name: strange table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."strange table" ("odd column", "binary", nullable) FROM stdin;
\.
COPY public."strange table" ("odd column", "binary", nullable) FROM '$$PATH$$/3472.dat';

--
-- Name: gamevault_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gamevault_user_id_seq', 1, true);


--
-- Name: progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.progress_id_seq', 2, true);


--
-- Name: gamevault_user gamevault_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gamevault_user
    ADD CONSTRAINT gamevault_user_pkey PRIMARY KEY (id);


--
-- Name: progress progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.progress
    ADD CONSTRAINT progress_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

